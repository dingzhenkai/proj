package com.hengda.sharelogin;

public class Constants {

    // 微博
    public static final String SINA_APP_KEY = "3921700954";
    public static final String SINA_REDIRECT_URL = "http://sns.whalecloud.com";
    public static final String SINA_SCOPE = "all";

    // QQ
    public static final String QQ_APP_ID = "100424468";
    public static final String QQ_SCOPE = "all";

    // 微信
    public static final String WECHAT_APP_ID = "wxdc1e388c3822c80b";
    public static final String WECHAT_APP_SECRET = "3baf1193c85774b3fd9d18447d76cab0";

}

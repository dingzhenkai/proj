package com.hengda.sharelogin;

import android.app.Activity;
import android.widget.Toast;

import com.hengda.zwf.sharelogin.IShareListener;

/**
 * 作者：祝文飞（Tailyou）
 * 邮箱：tailyou@163.com
 * 时间：2017/6/6 15:10
 * 描述：
 */
public class ShareListener implements IShareListener {

    private Activity activity;

    public ShareListener(Activity activity) {
        this.activity = activity;
    }

    @Override
    public void onSuccess() {
        String result = "分享成功";
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel() {
        String result = "取消分享";
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(String errorMsg) {
        Toast.makeText(activity, errorMsg, Toast.LENGTH_SHORT).show();
    }

}

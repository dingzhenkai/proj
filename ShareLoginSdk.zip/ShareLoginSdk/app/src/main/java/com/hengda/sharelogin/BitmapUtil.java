package com.hengda.sharelogin;

import android.graphics.Bitmap;
import android.media.ThumbnailUtils;

import com.hengda.zwf.commonutil.SDCardUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 作者：祝文飞（Tailyou）
 * 邮箱：tailyou@163.com
 * 时间：2017/6/6 16:35
 * 描述：
 */
public class BitmapUtil {

    /**
     * 保存Bitmap到SD卡
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 18:25
     */
    public static String saveBitmap(Bitmap bitmap, String dirPath, String imgName) {
        makeDir(dirPath);
        try {
            File f = new File(dirPath + imgName + ".png");
            FileOutputStream fOut = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
            fOut.flush();
            fOut.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return SDCardUtil.getSDCardPath() + imgName + ".png";
    }

    /**
     * 创建目录
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 18:23
     */
    public static void makeDir(String dirPath) {
        try {
            File file = new File(dirPath);
            if (!file.exists()) {
                file.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Bitmap 转 byte[]
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 19:19
     */
    public static byte[] bitmap2ByteArray(Bitmap src) {
        if (src == null) {
            return null;
        }
        final Bitmap bitmap;
        if (src.getWidth() > 250 || src.getHeight() > 250) {
            bitmap = ThumbnailUtils.extractThumbnail(src, 250, 250);
        } else {
            bitmap = src;
        }
        byte[] thumbData = null;
        ByteArrayOutputStream outputStream = null;
        try {
            outputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream);
            thumbData = outputStream.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.flush();
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return thumbData;
    }

}

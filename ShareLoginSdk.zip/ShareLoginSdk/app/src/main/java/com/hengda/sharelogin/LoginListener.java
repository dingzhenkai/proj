package com.hengda.sharelogin;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import com.hengda.zwf.sharelogin.ILoginListener;
import com.hengda.zwf.sharelogin.type.LoginPlatform;

public class LoginListener implements ILoginListener {

    private static final String TAG = "ILoginListener";
    private Activity activity;

    private
    @LoginPlatform
    String type;

    public LoginListener(Activity activity, @LoginPlatform String type) {
        this.activity = activity;
        this.type = type;
    }

    @Override
    public void onSuccess(String accessToken, String userId, long expiresIn) {
        Log.d(TAG, "accessToken = " + accessToken + "\nuid = " + userId + "\nexpires_in = " + expiresIn);
        String result = "登录成功，token:" + accessToken;
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onError(String msg) {
        String result = "登录失败,失败信息：" + msg;
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCancel() {
        String result = "取消登录";
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();
    }

}

package com.hengda.sharelogin;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.ScrollView;

import com.hengda.sharelogin.Print.ScreenCaptureApplication;
import com.hengda.zwf.commonutil.SDCardUtil;
import com.hengda.zwf.sharelogin.ShareLoginClient;
import com.hengda.zwf.sharelogin.content.ShareContent;
import com.hengda.zwf.sharelogin.content.ShareContentPage;
import com.hengda.zwf.sharelogin.content.ShareContentPicture;
import com.hengda.zwf.sharelogin.content.ShareContentText;
import com.hengda.zwf.sharelogin.type.LoginPlatform;
import com.hengda.zwf.sharelogin.type.SharePlatform;

public class MainActivity extends AppCompatActivity {

    private RadioGroup rgShareContentType;
    private ShareContent mShareContent;
    private Bitmap mLargeBitmap, mThumbBitmap,tmp;
    private String mLargeBmpPath,qpath;
    private byte[] mThumbBmpBytes;
    private MainActivity mActivity;
    ScrollView scrollView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mActivity = MainActivity.this;
        tmp = ((ScreenCaptureApplication) getApplication()).getPic();




       /* new Thread() {
            @Override
            public void run() {
                super.run();
                mLargeBitmap = ((BitmapDrawable) ContextCompat.getDrawable(mActivity, R.drawable.large)).getBitmap();
                mThumbBitmap = ((BitmapDrawable) ContextCompat.getDrawable(mActivity, R.drawable.kale)).getBitmap();
                mLargeBmpPath = BitmapUtil.saveBitmap(mLargeBitmap, SDCardUtil.getSDCardPath(), "share_pic");
                mThumbBmpBytes = BitmapUtil.bitmap2ByteArray(mThumbBitmap);
            }
        }.start();*/

        mLargeBmpPath = BitmapUtil.saveBitmap(tmp, SDCardUtil.getSDCardPath(), "share_pic");
        mThumbBmpBytes = BitmapUtil.bitmap2ByteArray(mThumbBitmap);
        mShareContent = new ShareContentText("我感觉这是个神奇的问题，昨天项目还一切OK");

        rgShareContentType = (RadioGroup) findViewById(R.id.rgShareContentType);
        rgShareContentType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.rbText:
                        mShareContent = new ShareContentText("我感觉这是个神奇的问题，昨天项目还一切OK");
                        break;
                    case R.id.rbPicture:
                        mShareContent = new ShareContentPicture(mLargeBmpPath);
                        break;
                    case R.id.rbWebPage:
                        mShareContent = new ShareContentPage("这是标题，好像不够长",
                                "我感觉这是个神奇的问题，昨天项目还一切OK",
                                "https://segmentfault.com/q/1010000009688458", mLargeBmpPath, mThumbBmpBytes);
                        break;
                }
            }
        });

    }

    public void doShareLogin(View view) {
        switch (view.getId()) {
            case R.id.btnSinaLogin://微博登录
                ShareLoginClient.login(mActivity, LoginPlatform.WEIBO, new LoginListener(mActivity, LoginPlatform.WEIBO));
                break;
            case R.id.btnQQLogin://QQ登录
                ShareLoginClient.login(mActivity, LoginPlatform.QQ, new LoginListener(mActivity, LoginPlatform.QQ));
                break;
            case R.id.btnWeChatLogin://微信登录
                ShareLoginClient.login(mActivity, LoginPlatform.WEIXIN, new LoginListener(mActivity, LoginPlatform.WEIXIN));
                break;
            case R.id.btnSina://分享-微博
                ShareLoginClient.share(mActivity, SharePlatform.WEIBO_TIME_LINE, mShareContent, new ShareListener(mActivity));
                break;
            case R.id.btnQQZone://分享-QQ空间
                ShareLoginClient.share(mActivity, SharePlatform.QQ_ZONE, mShareContent, new ShareListener(mActivity));
                break;
            case R.id.btnQQFriend://分享-QQ好友
                ShareLoginClient.share(mActivity, SharePlatform.QQ_FRIEND, mShareContent, new ShareListener(mActivity));
                break;
            case R.id.btnWxFriend://分享-微信好友
                ShareLoginClient.share(mActivity, SharePlatform.WEIXIN_FRIEND, mShareContent, new ShareListener(mActivity));
                break;
            case R.id.btnWxFriendZone://分享-微信朋友圈
                ShareLoginClient.share(mActivity, SharePlatform.WEIXIN_FRIEND_ZONE, mShareContent, new ShareListener(mActivity));
                break;
            case R.id.btnWxFavorite://分享-微信收藏
                ShareLoginClient.share(mActivity, SharePlatform.WEIXIN_FAVORITE, mShareContent, new ShareListener(mActivity));
                break;
        }
    }

}

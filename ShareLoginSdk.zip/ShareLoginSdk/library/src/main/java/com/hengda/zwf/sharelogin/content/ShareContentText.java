package com.hengda.zwf.sharelogin.content;

import android.os.Parcel;
import android.support.annotation.NonNull;

import com.hengda.zwf.sharelogin.type.ContentType;

/**
 * 分享类型-文本
 *
 * @author 祝文飞（Tailyou）
 * @time 2017/6/6 16:29
 */
public class ShareContentText implements ShareContent {

    private final String text;

    public ShareContentText(@NonNull String text) {
        this.text = text;
    }

    @Override
    public int getType() {
        return ContentType.TEXT;
    }

    @Override
    public String getTitle() {
        return null;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public String getUrl() {
        return null;
    }

    @Override
    public byte[] getThumbBmpBytes() {
        return null;
    }

    @Override
    public String getLargeBmpPath() {
        return null;
    }

    @Override
    public String getMusicUrl() {
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.text);
    }

    protected ShareContentText(Parcel in) {
        this.text = in.readString();
    }

    public static final Creator<ShareContentText> CREATOR = new Creator<ShareContentText>() {
        @Override
        public ShareContentText createFromParcel(Parcel source) {
            return new ShareContentText(source);
        }

        @Override
        public ShareContentText[] newArray(int size) {
            return new ShareContentText[size];
        }
    };
}
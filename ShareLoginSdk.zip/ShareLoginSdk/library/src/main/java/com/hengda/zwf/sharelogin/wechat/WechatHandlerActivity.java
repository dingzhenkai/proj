package com.hengda.zwf.sharelogin.wechat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.hengda.zwf.sharelogin.ILoginListener;
import com.hengda.zwf.sharelogin.IShareListener;
import com.hengda.zwf.sharelogin.ShareLoginClient;
import com.hengda.zwf.sharelogin.ShareLoginConfig;
import com.hengda.zwf.sharelogin.content.ShareContent;
import com.hengda.zwf.sharelogin.type.ContentType;
import com.hengda.zwf.sharelogin.type.SharePlatform;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.net.AsyncWeiboRunner;
import com.sina.weibo.sdk.net.RequestListener;
import com.sina.weibo.sdk.net.WeiboParameters;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXImageObject;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXTextObject;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import org.json.JSONException;
import org.json.JSONObject;

public class WechatHandlerActivity extends Activity implements IWXAPIEventHandler {

    private IWXAPI api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, ShareLoginConfig.weiXinAppId, true);
        api.handleIntent(getIntent(), this);
        finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (api != null) {
            api.handleIntent(getIntent(), this);
        }
        finish();
    }

    /**
     * 登录
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 13:46
     */
    public static void doLogin(@NonNull Context context) {
        String appId = ShareLoginConfig.weiXinAppId;
        IWXAPI api = WXAPIFactory.createWXAPI(context.getApplicationContext(), appId, true);
        api.registerApp(appId);
        SendAuth.Req req = new SendAuth.Req();
        req.scope = "snsapi_userinfo";
        api.sendReq(req);
    }

    /**
     * 分享
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 14:57
     */
    public void doShare(@NonNull Context context, ShareContent shareContent, @SharePlatform String shareType) {
        String weChatAppId = ShareLoginConfig.weiXinAppId;
        IWXAPI IWXAPI = WXAPIFactory.createWXAPI(context, weChatAppId, true);
        IWXAPI.registerApp(weChatAppId);
        IWXAPI.sendReq(setupShareRequest(shareContent, shareType));
    }

    /**
     * 组装分享请求
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 15:23
     */
    private SendMessageToWX.Req setupShareRequest(@NonNull ShareContent shareContent, @SharePlatform String shareType) {
        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = String.valueOf(System.currentTimeMillis());
        req.message = setupMessage(shareContent);
        switch (shareType) {
            case SharePlatform.WEIXIN_FRIEND:
                req.scene = SendMessageToWX.Req.WXSceneSession;
                break;
            case SharePlatform.WEIXIN_FRIEND_ZONE:
                req.scene = SendMessageToWX.Req.WXSceneTimeline;
                break;
            case SharePlatform.WEIXIN_FAVORITE:
                req.scene = SendMessageToWX.Req.WXSceneFavorite;
                break;
        }
        return req;
    }

    /**
     * 组装分享内容
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 15:23
     */
    @NonNull
    private WXMediaMessage setupMessage(@NonNull ShareContent shareContent) {
        WXMediaMessage msg = new WXMediaMessage();
        msg.title = shareContent.getTitle();
        msg.description = shareContent.getText();
        msg.thumbData = shareContent.getThumbBmpBytes();
        switch (shareContent.getType()) {
            case ContentType.TEXT:
                // 纯文字
                msg.mediaObject = getTextObj(shareContent);
                break;
            case ContentType.PIC:
                // 纯图片
                msg.mediaObject = getImageObj(shareContent);
                break;
            case ContentType.WEBPAGE:
                // 网页（图文）
                msg.mediaObject = getWebPageObj(shareContent);
                break;
            default:
                throw new UnsupportedOperationException("不支持的分享内容");
        }
        if (!msg.mediaObject.checkArgs()) {
            throw new IllegalArgumentException("分享信息的参数类型不正确");
        }
        return msg;
    }

    private WXMediaMessage.IMediaObject getTextObj(ShareContent shareContent) {
        WXTextObject text = new WXTextObject();
        text.text = shareContent.getText();
        return text;
    }

    private WXMediaMessage.IMediaObject getImageObj(ShareContent shareContent) {
        WXImageObject image = new WXImageObject();
        image.imagePath = shareContent.getLargeBmpPath();
        return image;
    }

    private WXMediaMessage.IMediaObject getWebPageObj(ShareContent shareContent) {
        WXWebpageObject webPage = new WXWebpageObject();
        webPage.webpageUrl = shareContent.getUrl();
        return webPage;
    }

    @Override
    public void onReq(BaseReq baseReq) {
        finish();
    }

    @Override
    public void onResp(BaseResp baseResp) {
        if (baseResp != null) {
            if (baseResp instanceof SendAuth.Resp && baseResp.getType() == 1) {
                parseLoginResp(this, (SendAuth.Resp) baseResp, ShareLoginClient.sLoginListener);
            } else {
                parseShareResp(baseResp, ShareLoginClient.sShareListener);
            }
        }
        finish();
    }

    /**
     * 解析登录响应
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 14:51
     */
    private void parseLoginResp(final Activity activity, SendAuth.Resp resp, ILoginListener listener) {
        switch (resp.errCode) {
            case BaseResp.ErrCode.ERR_OK:
                getAccessTokenByCode(activity, resp.code, listener);
                break;
            case BaseResp.ErrCode.ERR_USER_CANCEL:
                listener.onCancel();
                break;
            case BaseResp.ErrCode.ERR_AUTH_DENIED:
                listener.onError("用户拒绝授权");
                break;
            default:
                listener.onError("未知错误");
        }
    }

    /**
     * 根据登录成功后的code获取token
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 14:50
     */
    private void getAccessTokenByCode(Context context, String code, final ILoginListener listener) {
        WeiboParameters params = new WeiboParameters(null);
        params.put("appid", ShareLoginConfig.weiXinAppId);
        params.put("secret", ShareLoginConfig.weiXinSecret);
        params.put("grant_type", "authorization_code");
        params.put("code", code);
        new AsyncWeiboRunner(context).requestAsync("https://api.weixin.qq.com/sns/oauth2/access_token",
                params, "GET", new RequestListener() {
                    @Override
                    public void onComplete(String s) {
                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            String token = jsonObject.getString("access_token");
                            String openid = jsonObject.getString("openid");
                            long expires_in = jsonObject.getLong("expires_in");
                            listener.onSuccess(token, openid, expires_in);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onWeiboException(WeiboException e) {
                        listener.onError(e.getMessage());
                    }
                });
    }

    /**
     * 解析分享响应
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 14:55
     */
    private void parseShareResp(BaseResp resp, IShareListener listener) {
        switch (resp.errCode) {
            case BaseResp.ErrCode.ERR_OK:
                listener.onSuccess();
                break;
            case BaseResp.ErrCode.ERR_USER_CANCEL:
                listener.onCancel();
                break;
            case BaseResp.ErrCode.ERR_AUTH_DENIED:
                listener.onError("用户拒绝授权");
                break;
            case BaseResp.ErrCode.ERR_SENT_FAILED:
                listener.onError("发送失败");
                break;
            case BaseResp.ErrCode.ERR_COMM:
                listener.onError("一般错误");
                break;
            default:
                listener.onError("未知错误");
        }
    }

}

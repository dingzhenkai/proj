package com.hengda.zwf.sharelogin;

public class ShareLoginConfig {

    public static String weiXinAppId;
    public static String weiXinSecret;
    public static String weiBoAppId;
    public static String weiBoRedirectUrl;
    public static String weiBoScope;
    public static String qqAppId;
    public static String qqScope;
    public static String appName;
    public static boolean isDebug;

    public static class Builder {

        public ShareLoginConfig.Builder appName(String appName) {
            ShareLoginConfig.appName = appName;
            return this;
        }

        public ShareLoginConfig.Builder debug(boolean debug) {
            ShareLoginConfig.isDebug = debug;
            return this;
        }

        public ShareLoginConfig.Builder qq(String qqAppId, String scope) {
            ShareLoginConfig.qqAppId = qqAppId;
            ShareLoginConfig.qqScope = scope;
            return this;
        }

        public ShareLoginConfig.Builder weiBo(String weiBoAppId, String redirectUrl, String scope) {
            ShareLoginConfig.weiBoAppId = weiBoAppId;
            ShareLoginConfig.weiBoRedirectUrl = redirectUrl;
            ShareLoginConfig.weiBoScope = scope;
            return this;
        }

        public ShareLoginConfig.Builder weiXin(String weiXinAppId, String weiXinSecret) {
            ShareLoginConfig.weiXinAppId = weiXinAppId;
            ShareLoginConfig.weiXinSecret = weiXinSecret;
            return this;
        }

        public ShareLoginConfig build() {
            return new ShareLoginConfig();
        }

    }

}

package com.hengda.zwf.sharelogin.qq;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.hengda.zwf.sharelogin.ILoginListener;
import com.hengda.zwf.sharelogin.IShareListener;
import com.hengda.zwf.sharelogin.ShareLoginClient;
import com.hengda.zwf.sharelogin.ShareLoginConfig;
import com.hengda.zwf.sharelogin.content.ShareContent;
import com.hengda.zwf.sharelogin.type.ContentType;
import com.hengda.zwf.sharelogin.type.SharePlatform;
import com.tencent.connect.common.Constants;
import com.tencent.connect.share.QQShare;
import com.tencent.connect.share.QzonePublish;
import com.tencent.connect.share.QzoneShare;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

public class QQHandlerActivity extends Activity {

    private IUiListener mUIListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        switch (getIntent().getAction()) {
            case ShareLoginClient.ACTION_LOGIN:
                doLogin(ShareLoginClient.sLoginListener);
                break;
            case ShareLoginClient.ACTION_SHARE:
                ShareContent shareContent = (ShareContent) getIntent().getExtras().get(ShareLoginClient.SHARE_CONTENT);
                String sharePlatform = getIntent().getExtras().getString(ShareLoginClient.SHARE_PLATFORM);
                doShare(sharePlatform, shareContent, ShareLoginClient.sShareListener);
                break;
        }
    }

    /**
     * 登录
     *
     * @param loginListener
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 13:46
     */
    private void doLogin(final ILoginListener loginListener) {
        mUIListener = new IUiListener() {
            @Override
            public void onComplete(Object object) {
                try {
                    JSONObject jsonObject = ((JSONObject) object);
                    String token = jsonObject.getString(Constants.PARAM_ACCESS_TOKEN);
                    String openId = jsonObject.getString(Constants.PARAM_OPEN_ID);
                    String expires = jsonObject.getString(Constants.PARAM_EXPIRES_IN);
                    loginListener.onSuccess(token, openId, Long.valueOf(expires));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(UiError uiError) {
                loginListener.onError(uiError.errorMessage);
            }

            @Override
            public void onCancel() {
                loginListener.onCancel();
            }
        };
        Tencent tencent = Tencent.createInstance(ShareLoginConfig.qqAppId, this.getApplicationContext());
        if (!tencent.isSessionValid()) {
            tencent.login(this, ShareLoginConfig.qqScope, mUIListener);
        } else {
            tencent.logout(this);
        }
    }

    /**
     * 分享
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 14:57
     */
    private void doShare(String sharePlatform, ShareContent shareContent, final IShareListener shareListener) {
        mUIListener = new IUiListener() {
            @Override
            public void onComplete(Object response) {
                shareListener.onSuccess();
            }

            @Override
            public void onCancel() {
                shareListener.onCancel();
            }

            @Override
            public void onError(UiError e) {
                shareListener.onError(e.errorMessage);
            }
        };
        Tencent tencent = Tencent.createInstance(ShareLoginConfig.qqAppId, getApplicationContext());
        if (sharePlatform.equals(SharePlatform.QQ_FRIEND)) {
            switch (shareContent.getType()) {
                case ContentType.TEXT: //文本
                    shareQQText(shareContent.getText());
                    break;
                case ContentType.PIC: //图片
                    tencent.shareToQQ(this, setupQQImageBundle(shareContent), mUIListener);
                    break;
                case ContentType.WEBPAGE: //网页（图文）
                    tencent.shareToQQ(this, setupQQPageBundle(shareContent), mUIListener);
                    break;
            }
        } else {
            switch (shareContent.getType()) {
                case ContentType.TEXT: //文本
                    tencent.publishToQzone(this, setupQzoneTextBundle(shareContent), mUIListener);
                    break;
                case ContentType.PIC: //图片
                    tencent.publishToQzone(this, setupQzoneImageBundle(shareContent), mUIListener);
                    break;
                case ContentType.WEBPAGE: //网页（图文）
                    tencent.shareToQzone(this, setupQzonePageBundle(shareContent), mUIListener);
                    break;
            }
        }
    }

    /**
     * QQ好友-文本
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 17:06
     */
    public void shareQQText(String text) {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
        sendIntent.setType("text/plain");
        sendIntent.setClassName("com.tencent.mobileqq", "com.tencent.mobileqq.activity.JumpActivity");
        startActivity(sendIntent);
        finish();
    }

    /**
     * QQ好友-图片
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 15:26
     */
    private Bundle setupQQImageBundle(ShareContent shareContent) {
        Bundle params = new Bundle();
        params.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE, QQShare.SHARE_TO_QQ_TYPE_IMAGE);
        String uri = shareContent.getLargeBmpPath();
        if (uri.startsWith("http")) {
            params.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, uri);
        } else {
            params.putString(QQShare.SHARE_TO_QQ_IMAGE_LOCAL_URL, uri);
        }
        return params;
    }

    /**
     * QQ好友-网页（图文）
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 15:30
     */
    private Bundle setupQQPageBundle(ShareContent shareContent) {
        Bundle params = new Bundle();
        params.putString(QQShare.SHARE_TO_QQ_TITLE, shareContent.getTitle());
        params.putString(QQShare.SHARE_TO_QQ_SUMMARY, shareContent.getText());
        params.putString(QQShare.SHARE_TO_QQ_TARGET_URL, shareContent.getUrl());
        params.putString(QQShare.SHARE_TO_QQ_IMAGE_URL, shareContent.getLargeBmpPath());
        params.putInt(QQShare.SHARE_TO_QQ_KEY_TYPE, QQShare.SHARE_TO_QQ_TYPE_DEFAULT);
        return params;
    }

    /**
     * QQ空间-说说-文本
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/8 8:21
     */
    @NonNull
    private Bundle setupQzoneTextBundle(ShareContent shareContent) {
        Bundle params = new Bundle();
        params.putInt(QzonePublish.PUBLISH_TO_QZONE_KEY_TYPE, QzonePublish.PUBLISH_TO_QZONE_TYPE_PUBLISHMOOD);
        params.putString(QzonePublish.PUBLISH_TO_QZONE_SUMMARY, shareContent.getText());
        return params;
    }

    /**
     * QQ空间-说说-图片
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/8 8:21
     */
    @NonNull
    private Bundle setupQzoneImageBundle(ShareContent shareContent) {
        Bundle params = new Bundle();
        params.putInt(QzonePublish.PUBLISH_TO_QZONE_KEY_TYPE, QzonePublish.PUBLISH_TO_QZONE_TYPE_PUBLISHMOOD);
        ArrayList<String> value = new ArrayList<>(Collections.singletonList(shareContent.getLargeBmpPath()));
        params.putStringArrayList(QzonePublish.PUBLISH_TO_QZONE_IMAGE_URL, value);
        return params;
    }

    /**
     * QQ空间分享-网页（图文）
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 12:12
     */
    private Bundle setupQzonePageBundle(ShareContent shareContent) {
        Bundle params = new Bundle();
        params.putInt(QzoneShare.SHARE_TO_QZONE_KEY_TYPE, QzoneShare.SHARE_TO_QZONE_TYPE_IMAGE_TEXT);
        params.putString(QzoneShare.SHARE_TO_QQ_TITLE, shareContent.getTitle());
        params.putString(QzoneShare.SHARE_TO_QQ_SUMMARY, shareContent.getText());
        params.putString(QzoneShare.SHARE_TO_QQ_TARGET_URL, shareContent.getUrl());
        ArrayList<String> value = new ArrayList<>(Collections.singletonList(shareContent.getLargeBmpPath()));
        params.putStringArrayList(QzoneShare.SHARE_TO_QQ_IMAGE_URL, value);
        return params;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mUIListener != null) {
            Tencent.handleResultData(data, mUIListener);
        }
        finish();
    }

}

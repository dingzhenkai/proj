package com.hengda.zwf.sharelogin.content;

import android.os.Parcel;
import android.support.annotation.NonNull;

import com.hengda.zwf.sharelogin.type.ContentType;

/**
 * 分享类型-图片
 *
 * @author 祝文飞（Tailyou）
 * @time 2017/6/6 16:29
 */
public class ShareContentPicture implements ShareContent {

    private final String largeBmpPath;

    public ShareContentPicture(@NonNull String largeBmpPath) {
        this.largeBmpPath = largeBmpPath;
    }

    @Override
    public int getType() {
        return ContentType.PIC;
    }

    @Override
    public String getTitle() {
        return null;
    }

    @Override
    public String getText() {
        return null;
    }

    @Override
    public String getUrl() {
        return null;
    }

    @Override
    public byte[] getThumbBmpBytes() {
        return null;
    }

    @Override
    public String getLargeBmpPath() {
        return largeBmpPath;
    }

    @Override
    public String getMusicUrl() {
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.largeBmpPath);
    }

    protected ShareContentPicture(Parcel in) {
        this.largeBmpPath = in.readString();
    }

    public static final Creator<ShareContentPicture> CREATOR = new Creator<ShareContentPicture>() {
        @Override
        public ShareContentPicture createFromParcel(Parcel source) {
            return new ShareContentPicture(source);
        }

        @Override
        public ShareContentPicture[] newArray(int size) {
            return new ShareContentPicture[size];
        }
    };
}
package com.hengda.zwf.sharelogin;

/**
 * 作者：祝文飞（Tailyou）
 * 邮箱：tailyou@163.com
 * 时间：2017/6/6 13:21
 * 描述：第三方登录回调
 */
public interface ILoginListener {

    void onSuccess(String accessToken, String uId, long expiresIn);

    void onError(String errorMsg);

    void onCancel();

}

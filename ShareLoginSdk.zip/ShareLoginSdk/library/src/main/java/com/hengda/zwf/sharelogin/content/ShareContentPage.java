package com.hengda.zwf.sharelogin.content;

import android.os.Parcel;

import com.hengda.zwf.sharelogin.type.ContentType;

/**
 * 分享类型-网页
 *
 * @author 祝文飞（Tailyou）
 * @time 2017/6/6 16:29
 */
public class ShareContentPage implements ShareContent {

    private final String title;
    private final String text;
    private final String url;
    private final String largeBmpPath;
    private byte[] thumbBmpBytes;

    public ShareContentPage(String title, String text, String url, String largeBmpPath, byte[] thumbBmpBytes) {
        this.title = title;
        this.text = text;
        this.url = url;
        this.largeBmpPath = largeBmpPath;
        this.thumbBmpBytes = thumbBmpBytes;
    }

    @Override
    public int getType() {
        return ContentType.WEBPAGE;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public byte[] getThumbBmpBytes() {
        return thumbBmpBytes;
    }

    @Override
    public String getLargeBmpPath() {
        return largeBmpPath;
    }

    @Override
    public String getMusicUrl() {
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.text);
        dest.writeString(this.url);
        dest.writeString(this.largeBmpPath);
        dest.writeByteArray(this.thumbBmpBytes);
    }

    protected ShareContentPage(Parcel in) {
        this.title = in.readString();
        this.text = in.readString();
        this.url = in.readString();
        this.largeBmpPath = in.readString();
        this.thumbBmpBytes = in.createByteArray();
    }

    public static final Creator<ShareContentPage> CREATOR = new Creator<ShareContentPage>() {
        @Override
        public ShareContentPage createFromParcel(Parcel source) {
            return new ShareContentPage(source);
        }

        @Override
        public ShareContentPage[] newArray(int size) {
            return new ShareContentPage[size];
        }
    };
}
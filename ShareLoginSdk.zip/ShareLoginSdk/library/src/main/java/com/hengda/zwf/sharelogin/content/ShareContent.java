package com.hengda.zwf.sharelogin.content;

import android.os.Parcelable;

import com.hengda.zwf.sharelogin.type.ContentType;


/**
 * Created by echo on 5/18/15.
 */

public interface ShareContent extends Parcelable {

    /**
     * @return 分享的方式
     */
    @ContentType
    int getType();

    /**
     * 标题
     */
    String getTitle();

    /**
     * 文本(摘要)
     */
    String getText();

    /**
     * 获取跳转的链接
     */
    String getUrl();

    /**
     * 分享的缩略图片
     */
    byte[] getThumbBmpBytes();

    /**
     * 分享大图路径
     */
    String getLargeBmpPath();

    /**
     * 音频url
     */
    String getMusicUrl();

}

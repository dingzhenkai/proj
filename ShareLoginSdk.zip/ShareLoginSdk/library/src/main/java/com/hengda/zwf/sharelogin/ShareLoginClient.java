package com.hengda.zwf.sharelogin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.hengda.zwf.sharelogin.content.ShareContent;
import com.hengda.zwf.sharelogin.qq.QQHandlerActivity;
import com.hengda.zwf.sharelogin.sina.SinaHandlerActivity;
import com.hengda.zwf.sharelogin.type.LoginPlatform;
import com.hengda.zwf.sharelogin.type.SharePlatform;
import com.hengda.zwf.sharelogin.wechat.WechatHandlerActivity;
import com.sina.weibo.sdk.utils.LogUtil;

import java.util.List;
import java.util.Locale;

import static com.hengda.zwf.sharelogin.type.LoginPlatform.QQ;
import static com.hengda.zwf.sharelogin.type.LoginPlatform.WEIBO;
import static com.hengda.zwf.sharelogin.type.LoginPlatform.WEIXIN;
import static com.hengda.zwf.sharelogin.type.SharePlatform.QQ_FRIEND;
import static com.hengda.zwf.sharelogin.type.SharePlatform.QQ_ZONE;
import static com.hengda.zwf.sharelogin.type.SharePlatform.WEIBO_TIME_LINE;
import static com.hengda.zwf.sharelogin.type.SharePlatform.WEIXIN_FAVORITE;
import static com.hengda.zwf.sharelogin.type.SharePlatform.WEIXIN_FRIEND;
import static com.hengda.zwf.sharelogin.type.SharePlatform.WEIXIN_FRIEND_ZONE;

/**
 * 作者：祝文飞（Tailyou）
 * 邮箱：tailyou@163.com
 * 时间：2017/6/6 11:02
 * 描述：
 */
public class ShareLoginClient {

    public static final String SHARE_CONTENT = "SHARE_CONTENT";
    public static final String SHARE_PLATFORM = "SHARE_PLATFORM";
    public static final String ACTION_LOGIN = "ACTION_LOGIN";
    public static final String ACTION_SHARE = "ACTION_SHARE";

    public static ILoginListener sLoginListener;
    public static IShareListener sShareListener;

    private ShareLoginClient() {
    }



    public static void init(ShareLoginConfig slc) {
        if (slc.isDebug) {
            LogUtil.enableLog();
        } else {
            LogUtil.disableLog();
        }
    }

    public static boolean isQQInstalled(Context context) {
        return isInstalled(context, "com.tencent.mobileqq");
    }

    public static boolean isWeiBoInstalled(Context context) {
        return isInstalled(context, "com.sina.weibo");
    }

    public static boolean isWeiXinInstalled(Context context) {
        return isInstalled(context, "com.tencent.mm");
    }

    /**
     * 根据包名判断是否安装
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 11:09
     */
    private static boolean isInstalled(Context context, String pkgName) {
        PackageManager pm = context.getApplicationContext().getPackageManager();
        if (pm == null) {
            return false;
        }
        List<PackageInfo> packages = pm.getInstalledPackages(0);
        for (PackageInfo info : packages) {
            String name = info.packageName.toLowerCase(Locale.ENGLISH);
            if (pkgName.equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 第三方登录
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/6 13:52
     */
    public static void login(Activity activity, @LoginPlatform String type, ILoginListener loginListener) {
        ShareLoginClient.sLoginListener = loginListener;
        switch (type) {
            case WEIBO://微博
                if (isWeiBoInstalled(activity)) {
                    toLogin(activity, SinaHandlerActivity.class);
                } else {
                    if (loginListener != null) {
                        loginListener.onError("未安装微博");
                    }
                }
                break;
            case QQ://腾讯QQ
                if (isQQInstalled(activity)) {
                    toLogin(activity, QQHandlerActivity.class);
                } else {
                    if (loginListener != null) {
                        loginListener.onError("未安装QQ");
                    }
                }
                break;
            case WEIXIN://微信
                if (isWeiXinInstalled(activity)) {
                    WechatHandlerActivity.doLogin(activity);
                    activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                } else {
                    if (loginListener != null) {
                        loginListener.onError("未安装微信");
                    }
                }
                break;
        }
    }

    /**
     * 跳转->第三方登录
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 9:50
     */
    private static void toLogin(Activity activity, Class<? extends Activity> cls) {
        Intent intent = new Intent(activity, cls);
        intent.setAction(ACTION_LOGIN);
        activity.startActivity(intent);
        activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * 第三方分享
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 9:51
     */
    public static void share(final Activity activity, @SharePlatform String sharePlatform, final ShareContent shareContent, IShareListener shareListener) {
        ShareLoginClient.sShareListener = shareListener;
        switch (sharePlatform) {
            //微博
            case WEIBO_TIME_LINE:
                if (isWeiBoInstalled(activity)) {
                    toShare(activity, sharePlatform, shareContent, SinaHandlerActivity.class);
                } else {
                    if (shareListener != null) {
                        shareListener.onError("未安装微博");
                    }
                }
                break;
            //QQ
            case QQ_FRIEND:
            case QQ_ZONE:
                if (isQQInstalled(activity)) {
                    toShare(activity, sharePlatform, shareContent, QQHandlerActivity.class);
                } else {
                    if (shareListener != null) {
                        shareListener.onError("未安装QQ");
                    }
                }
                break;
            //微信
            case WEIXIN_FRIEND:
            case WEIXIN_FRIEND_ZONE:
            case WEIXIN_FAVORITE:
                if (isWeiXinInstalled(activity)) {
                    new WechatHandlerActivity().doShare(activity, shareContent, sharePlatform);
                } else {
                    if (shareListener != null) {
                        shareListener.onError("未安装微信");
                    }
                }
                break;
        }
    }

    /**
     * 跳转->第三方分享
     *
     * @author 祝文飞（Tailyou）
     * @time 2017/6/7 9:57
     */
    private static void toShare(Activity activity, String sharePlatform,
                                ShareContent shareContent, Class<? extends Activity> cls) {
        Intent intent = new Intent(activity, cls);
        intent.setAction(ACTION_SHARE);
        intent.putExtra(SHARE_PLATFORM, sharePlatform);
        intent.putExtra(SHARE_CONTENT, shareContent);
        activity.startActivity(intent);
        activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

}
